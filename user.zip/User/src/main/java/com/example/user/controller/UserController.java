package com.example.user.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.user.entity.user;
import com.example.user.service.UserService;



@RestController
public class UserController {
	@Autowired
	UserService us1;
	 
	 @PostMapping("/usr")
	 public user saveUser(@RequestBody user user) {
	 	
	 	return us1.saveuser(user);

}
	 @GetMapping("/usr")
	    public List<user> fetchuserList() {
	        //LOGGER.info("Inside fetchDepartmentList of DepartmentController");
	        return us1.fetchuserList();
	    }
	    


	    @GetMapping("/usr/{id}")
	    public user fetchUserById(@PathVariable("id") Long id)
	            {
	        return us1.fetchuserById(id);
	    }
	    
	    @DeleteMapping("/usr/{id}")
	    public String deleteuserById(@PathVariable("id") Long id) {
	        us1.deleteuserById(id);
	        return "user deleted Successfully!!";
	    }
	    @PutMapping("/usr/{id}")
	    public user updateUser(@PathVariable("id") Long id,
	                                       @RequestBody user user) {
	        return us1.updateuser(id,user);
	    }
}