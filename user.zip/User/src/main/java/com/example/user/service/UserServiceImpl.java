package com.example.user.service;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.user.entity.user;
import com.example.user.repository.UserRepository;


	@Service
	public class UserServiceImpl implements UserService {

	    @Autowired
	     UserRepository ur1;
	    
        @Override
	    public user saveuser(user user) {
	        return ur1.save(user);
	    }

	    @Override
	    public List<user> fetchuserList() {
	        return ur1.findAll();
	    }

	   @Override
	   public user fetchuserById(Long userId) {
		   return ur1.findById(userId).get();
	   }
		
	   @Override
	   public void deleteuserById(Long userId) {
	       return;
	   }


	   @Override
	   public user updateuser(Long userId, user user) {
	       user userDB = ur1.findById(userId).get();

	       if(Objects.nonNull(user.getUserName()) &&
	       !"".equalsIgnoreCase(user.getUserName())) {
	           userDB.setUserName(user.getUserName());
	       }

	       if(Objects.nonNull(user.getUserPassword()) &&
	   
	    		   !"".equalsIgnoreCase(user.getUserPassword())) {
	           userDB.setUserPassword(user.getUserPassword());
	       }

	       return ur1.save(userDB);
	   }

	@Override
	public user updateuser1(Long userId, user user) {
		// TODO Auto-generated method stub
		return ur1.save(user);
	}

	@Override
	public user saveUser(user user) {
		// TODO Auto-generated method stub
		return ur1.save(user);
	}

	    
	    

	}

